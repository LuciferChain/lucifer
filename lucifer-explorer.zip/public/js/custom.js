$(document).ready(function() {
  /* Add custom javascript code here */
});